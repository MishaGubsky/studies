import numpy as np
from second import second_phase as second_phase


def first_phase(c, b, A):
    size = c.size + A.shape[0]
    c_new, B, A_new, x = [], np.matrix(np.zeros(A.shape[0]), dtype=int), np.matrix(np.zeros((A.shape[0], size))), np.matrix(np.zeros(size))

    for i in range(c.size):
        c_new.append(0)
        x[0, i] = 0
        A_new[:, i] = A[:, i]

    for i in range(A.shape[0]):
        c_new.append(-1)
        B[0, i] = c.size + i
        x[0, c.size + i] = b[0, i]
        A_new[i, c.size + i] = 1

    B_start = np.matrix(B, dtype=int)
    c_new = np.matrix(c_new)
    second_phase(c_new, B, x, A_new)

    for i in range(A_new.shape[0]):
        if x[0, B_start[0, i]] != 0:
            return 'System is not sovmestna!'
        if B[0, i] in B_start:
            value = B[0, i]
            delete_artificial_indexes(i, value, B, B_start, A_new)
            if value == B[0, i]:
                row = value - (A_new.shape[1] -B.size)
                A_new = update_row(A_new, row)
                A = update_row(A, row)
                B = update_col(B, row)
                c_new = update_col(c_new, row)
                c = update_col(c, row)
                # print 'A_update', A
                # print 'A_upd', A_new
                # print 'B_update', B
                # print 'c_update', c
                return np.matrix(x[0, 0:c.size])

    x_opt = np.matrix(x[0, 0:c.size])
    # print 'x_opt', x_opt
    # print 'B', B
    # print 'c', c
    # print 'A', A

    return x_opt, B


def update_row(matrix, row):
    matrix_upd = np.matrix(np.zeros((matrix.shape[0]-1, matrix.shape[1])))
    matrix_upd[0: row, :] = matrix[0: row, :]
    matrix_upd[row:, :] = matrix[row+1:, :]
    return matrix_upd


def update_col(matrix, col):
    matrix_upd = np.matrix(np.zeros((matrix.shape[0], matrix.shape[1]-1)))
    matrix_upd[:, 0:col] = matrix[:, 0:col]
    matrix_upd[:, col:] = matrix[:, col+1:]
    return matrix_upd


def delete_artificial_indexes(index, value, B, B_start, A):
    Ab = np.matrix(np.zeros((A.shape[0], B.size)))
    for i in range(B[0].size):
        Ab[:, i] = A[:, B[0, i]]

    reverse_Ab = np.linalg.inv(Ab)

    N = []
    for i in range(A.shape[1]):
        if i not in B_start:
            N.append(i)

    temp = []
    for i in N:
        if i not in B:
            l = reverse_Ab * A[:, i]
            temp.append(l[index])

    for i in temp:
        if i != 0:
            B[0, index] = i
            return


if __name__ == '__main__':
    c = np.matrix([1, 2, 0])
    b = np.matrix([4, 2])
    A = np.matrix([[1, 3, 1], [0, 2, 1]])

    # c = np.matrix([1, 0, 0, 0])
    # b = np.matrix([2, 3])
    # A = np.matrix([[1, 1, 1, 0], [1, -1, 0, -1]])

    # c = np.matrix([1, 0, 0])
    # b = np.matrix([0, 0])
    # A = np.matrix([[1, 1, 1], [2, 2, 2]])

    print 'x_opt', first_phase(c, b, A)[0]
    print 'B', first_phase(c, b, A)[1]
